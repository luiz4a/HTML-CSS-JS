//Dom

const horas = document.querySelector('#horas');
const minutos = document.querySelector('#minutos');
const segundos = document.querySelector('#segundos');

//Eventos
setInterval(atualizarRelogio, 1000);
atualizarRelogio();

//Funções
function atualizarRelogio() {

    let dataAtual = new Date();
    let hr = dataAtual.getHours();
    let min = dataAtual.getMinutes();
    let seg = dataAtual.getSeconds();

    hr = hr < 10 ? '0' + hr : hr;
    min = min < 10 ? '0' + min : min;
    seg = seg < 10 ? '0' + seg : seg;

    horas.textContent = hr;
    minutos.textContent = min;
    segundos.textContent = seg;

}
